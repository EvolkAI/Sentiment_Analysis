<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <title>Sentiment Analysis</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header>
        <img src="images\evolkai.png" alt="logo" class="logo">
    </header>
    <h1>Sentiment Analysis</h1>
    <div class="container">
        <div class="form">
            <div class="form-group">
                <form method="post">    
                    <textarea name="comment" rows="4" cols="50"></textarea><br><br>
                    <input type="submit" name="submit" value="Predict">
                </form>
            </div>
        </div>
    </div>
    <?php

use function PHPSTORM_META\type;

$positive = "webpage/images/positive.jpg";
$negative = "webpage/images/negative.jpg";
$neutral = "webpage/images/neutral.jpg";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $comment = $_POST["comment"];
    $output = shell_exec("python sentiment_analysis.py \"$comment\"");
    echo "<h3>Predicted Sentiment: $output</h3>";
    
    if ($output == "positive") {
        echo "<img src='$positive' alt='positive' width='auto' height='500px'>";
    } elseif ($output == "negative") {
        echo "<img src='$negative' alt='negative' width='auto' height='500px'>";
    } elseif ($output == "neutral") {
        echo "<img src='$neutral' alt='neutral' width='auto' height='500px'>";
    }
}
?>

</body>
</html> -->

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sentiment Analysis</title>
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <header>
        <img src="images/evolkai.png" alt="logo" class="logo">
        <img src= "images/negative.png" alt='negative' width='1px' height='1px'>
        <img src= "images/positive.png" alt='positive' width='1px' height='1px'>
        <img src= "images/neutral.png" alt='neutral' width='1px' height='1px'>
        
    </header>
    <h1>Sentiment Analysis</h1>
    <div class="container">
        <section class="left-section">
            <div class="form">
                <div class="form-group">
                    <form method="post">    
                        <textarea name="comment" rows="4" cols="50"></textarea><br><br>
                        <input type="submit" name="submit" value="Predict">
                    </form>
                </div>
            </div>
        </section>
   
            <section class="right-section">
            <!-- <img src= "<?php $image_file ?>" alt='negative' width='auto' height='500px'> -->
            <!-- <?php
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                $comment = $_POST["comment"];
                $output = shell_exec("python sentiment_analysis.py \"$comment\"");
                echo "<h3>Predicted Sentiment: $output</h3>";
            }
            ?> -->

        <?php
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $comment = $_POST["comment"];
            $output = shell_exec("python sentiment_analysis.py \"$comment\"");

            // Define the image file names
            $positive_image = 'images/positive.png';
            $negative_image = 'images/negative.png';
            $neutral_image = 'images/neutral.png';

            echo "<img src= 'images/$output.png' alt='sentiment' width='auto' height='500px'>";

        }
        ?>

        </section>
    </div>
</body>
</html>

