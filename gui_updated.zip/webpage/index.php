<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sentiment Analysis</title>
    <link rel="stylesheet" href="style.css">
    <link rel="icon" type="image/png" href="images/emo/Joy.png" alt="evolkai">
</head>

<!-- <style>
    body{
        background: linear-gradient(45deg, #c4e0e5, #f2e2e3);
    }
</style> -->
<body>

    <header>
        <nav class="navbar">
            <img src="images/evolkai.png" alt="logo" class="logo">
        </nav>
    </header>

    <div class="heading">
        SenText
    </div>

    <main>
        <div class="container">
            <section class="left-section">
                <div class="form">
                    <div class="form-group">
                        <form method="post">    
                            <textarea name="comment" rows="28" cols="50"></textarea><br><br>
                            <input type="submit" name="submit" value="Predict">
                        </form>
                    </div>
                </div>
            </section>
       
            <section class="right-section">
                
                <?php
                if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $comment = $_POST["comment"];
                    $output = shell_exec("python sentiment_analysis.py \"$comment\"");
        
                    // Define the image file names
                    $positive_image = 'images/positive.png';
                    $negative_image = 'images/negative.png';
                    $neutral_image = 'images/neutral.png';
        
                    echo "<div class= 'image' ><img src= 'images/emo/$output.png' alt='sentiment' width='auto' height='400px'></div>";
                    echo "<div class= 'output'><h3>Predicted Sentiment: $output</h3></div>";
        
                }
                ?>
            </section>
        </div>
    </main>

</body>
</html>

