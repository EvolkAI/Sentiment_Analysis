import pandas as pd
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
import string
import joblib
import warnings
import sys

warnings.filterwarnings('ignore')

# Preprocessing
def preprocess_text(text):
    if isinstance(text, str):  # Check if the input is a string
        # Tokenization
        tokens = word_tokenize(text)
        
        # Remove punctuation
        tokens = [token for token in tokens if token not in string.punctuation]
        
        # Remove stop words
        stop_words = set(stopwords.words('english'))
        tokens = [token for token in tokens if token.lower() not in stop_words]
        
        # Convert tokens back to a single string
        preprocessed_text = ' '.join(tokens)
        
        return preprocessed_text
    else:
        return ''

# Function to predict the emotional sentiment of a sentence
def predict_sentiment(sentence):
    # Preprocess the input sentence
    preprocessed_sentence = preprocess_text(sentence)
    
    # Convert the preprocessed sentence to numerical features
    sentence_features = vectorizer.transform([preprocessed_sentence])
    
    # Predict the sentiment
    sentiment = classifier.predict(sentence_features)[0]
    
    return sentiment


# Load the sentiment analysis dataset (with text and sentiment labels)

data = pd.read_csv('text.csv', encoding='latin-1')

# Apply preprocessing to the text data
data['preprocessed_text'] = data['sentence'].apply(preprocess_text)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(data['sentence'], data['emotion'], test_size=0.2, random_state=42)

# Convert text to numerical features using Bag-of-Words
vectorizer = CountVectorizer()
X_train_features = vectorizer.fit_transform(X_train)
X_test_features = vectorizer.transform(X_test)

# Load the saved model
classifier = joblib.load('emotion_classifier_model.joblib')

# Read the input sentence from PHP script
input_sentence = sys.argv[1]

# Predict the sentiment
predicted_sentiment = predict_sentiment(input_sentence)

# convert the predicted sentiment in string
sentiment = str(predicted_sentiment)

sentiments = {"[ 1.  0.  0.  0.  0.  0.  0.]" : "Joy", "[ 0.  0.  1.  0.  0.  0.  0.]": "Anger", '[ 0.  0.  0.  1.  0.  0.  0.]': "Sadness", "[ 0.  1.  0.  0.  0.  0.  0.]" : "Fear", "[ 0.  0.  0.  0.  1.  0.  0.]" : "Disgust", "[ 0.  0.  0.  0.  0.  0.  1.]": "Guilt", "[ 0.  0.  0.  0.  0.  1.  0.]": "Shame"}

print(sentiments[sentiment])
    



